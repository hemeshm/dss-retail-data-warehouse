# generate_date_dimension.py
import pandas as pd
import pymysql

'''
Connecting to MySQL (DB credentials updated)
'''
connection = pymysql.connect(
    host='localhost',
    port=int(3306),
    user='dss_user0',
    passwd='73841A',
    db='retail_dss0'
)
cursor = connection.cursor()

'''
Generating the date Dimension
'''
# Create dates dimension table (from 1990-01-01 to 2022-12-31)
start_date = pd.to_datetime('1990-01-01').date()
end_date = pd.to_datetime('2022-12-31').date()
dates = pd.date_range(start_date, end_date).to_series()
date_table = pd.DataFrame({
    'Dates': dates.dt.strftime('%Y-%m-%d'),
    'Day_name': dates.dt.day_name(),
    'Day_number_in_week': dates.dt.weekday + 1,
    'Day_number_in_month': dates.dt.day,
    'Day_number_overall': dates.dt.dayofyear,
    'Is_weekend': dates.dt.weekday.isin([5,6]).astype(int),
    'Week_number_in_year': dates.dt.isocalendar().week,
    'Month_name': dates.dt.month_name(),
    'Month_number': dates.dt.month,
    'Year_name': dates.dt.year,
    'Quarter': dates.dt.quarter,
    'Holiday': 0
})

cursor.execute('DROP TABLE IF EXISTS dwh_date;')
cursor.execute('''
CREATE TABLE dwh_date (
    Dates DATE PRIMARY KEY,
    Day_name VARCHAR(20),
    Day_number_in_week INT,
    Day_number_in_month INT,
    Day_number_overall INT,
    Is_weekend INT,
    Week_number_in_year INT,
    Month_name VARCHAR(20),
    Month_number INT,
    Year_name INT,
    Quarter INT,
    Holiday INT
);
''')

for _, row in date_table.iterrows():
    cursor.execute(
        "INSERT INTO dwh_date VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
        (row.Dates, row.Day_name, int(row.Day_number_in_week), int(row.Day_number_in_month),
         int(row.Day_number_overall), int(row.Is_weekend), int(row.Week_number_in_year),
         row.Month_name, int(row.Month_number), int(row.Year_name), int(row.Quarter), int(row.Holiday))
    )
connection.commit()
cursor.close()
connection.close()
